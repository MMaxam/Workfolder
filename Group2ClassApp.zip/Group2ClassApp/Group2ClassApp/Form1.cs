﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Group2ClassApp.DataClass;

namespace Group2ClassApp
{

    

    public partial class Form1 : Form
    {
        MainClass mc = new MainClass();


        public Form1()
        {
            InitializeComponent();
        }

        DataTable dt = new DataTable("tblStudents");

  

        private void Form1_Load(object sender, EventArgs e)
        {
            //
            DataTable dt = mc.Select();
            dgvTable.DataSource = dt;
          
        }

        private void TxtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)13)
            {
                DataTable dt = mc.Select();
                DataView dv = dt.DefaultView;
                //Filter the DataViewGrid using the txtBox -- (txtSearchBar)
                dv.RowFilter = string.Format("Course like '%{0}%' OR StudentNo like '%{0}%'", txtSearch.Text);
                dgvTable.DataSource = dv.ToTable();
            }
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            txtStudentNo.Text = "";
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtContactNo.Text = "";
            txtEmail.Text = "";
            txtIDNumber.Text = "";
            txtCourse.Text = "";
            txtDateEnrol.Text = "";
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {

            //get the value froom the 
            String StuNumb = "STD";

            Count = dgvTable.RowCount;
            StuNumb += "" + Count;
            mc.StudentNo = StuNumb;

            mc.FirstName = txtFirstName.Text;
            mc.LastName = txtLastName.Text;
            mc.ContactNo = txtContactNo.Text;
            mc.EmailAddress = txtEmail.Text;
            mc.IDNumber = txtIDNumber.Text;
            mc.Course = txtCourse.Text;
            mc.DateEnrolled = txtDateEnrol.Text;

            //Load the data on the database
            //connect to the database
            bool success = mc.Insert(mc);
            if (success)
            {
                MessageBox.Show("New Student successfully Inserted.");
            }
            else
            {
                MessageBox.Show("Failed to Insert data");
            }


            DataTable dt = mc.Select();
            dgvTable.DataSource = dt;
        }

        int Count;
        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            //get the value from the textfields in the form so that they can be sent to the MainClass (mc) 
            mc.StudentNo = txtStudentNo.Text;
            mc.FirstName = txtFirstName.Text;
            mc.LastName = txtLastName.Text;
            mc.ContactNo = txtContactNo.Text;
            mc.EmailAddress = txtEmail.Text;
            mc.IDNumber = txtIDNumber.Text;
            mc.Course = txtCourse.Text;
            mc.DateEnrolled = txtDateEnrol.Text;

            //Load the data on the database
            //connect to the database
            bool success = mc.Update(mc);
            if (success)
            {
                MessageBox.Show("New Student successfully Updated.");
            }
            else
            {
                MessageBox.Show("Failed to Update data");
            }

            DataTable dt = mc.Select();
            dgvTable.DataSource = dt;


        }

        private void DgvTable_Enter(object sender, EventArgs e)
        {
            DataTable dt = mc.Select();
            dgvTable.DataSource = dt;
        }

        private void BtnGo_Click(object sender, EventArgs e)
        {
            DataTable dt = mc.Select();
            DataView dv = dt.DefaultView;
            //Filter the DataViewGrid using the txtBox -- (txtSearchBar)
            dv.RowFilter = string.Format("Course like '%{0}%' OR StudentNo like '%{0}%'", txtSearch.Text);
            dgvTable.DataSource = dv.ToTable();
        }

        private void DgvTable_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            //For every row selected the data of that specific row will be populated on the textfields

            int RowIndex = e.RowIndex;
            txtStudentNo.Text = dgvTable.Rows[RowIndex].Cells[0].Value.ToString();
            txtFirstName.Text = dgvTable.Rows[RowIndex].Cells[1].Value.ToString();
            txtLastName.Text = dgvTable.Rows[RowIndex].Cells[2].Value.ToString();
            txtContactNo.Text = dgvTable.Rows[RowIndex].Cells[3].Value.ToString();
            txtEmail.Text = dgvTable.Rows[RowIndex].Cells[4].Value.ToString();
            txtIDNumber.Text = dgvTable.Rows[RowIndex].Cells[5].Value.ToString();
            txtCourse.Text = dgvTable.Rows[RowIndex].Cells[6].Value.ToString();
            txtDateEnrol.Text = dgvTable.Rows[RowIndex].Cells[7].Value.ToString();

        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            mc.StudentNo = txtStudentNo.Text;

            //Load the data on the database
            //connect to the database
            bool success = mc.Delete(mc);
            if (success)
            {
                MessageBox.Show("Successfully deleted selected data.");
            }
            else
            {
                MessageBox.Show("Failed to Delete selected data.");
            }
            
            DataTable dt = mc.Select();
            dgvTable.DataSource = dt;


        }
    }
}
